import json, sys, pathlib
d = pathlib.Path(sys.argv[1])
ch = json.load(open(d/"chapters.json"))
ac = {r["id"]: r for r in json.load(open(d/"actors.json"))}
wv = json.load(open(d/"weapons_vehicles.json"))
wp = {r["id"]: r for r in wv["weapons"]}
vh = {r["id"]: r for r in wv["vehicles"]}
au = {r["id"]: r for r in json.load(open(d/"audio.json"))}
cid = {r["id"] for r in ch}
issues = []
for r in ch:
    for k, v in r.items():
        if v is None and k != "next":
            issues.append(f"chapter {r['id']}: empty {k}")
    for a in r["actors"]:
        if a not in ac: issues.append(f"chapter {r['id']}: unknown actor {a}")
    for w in r["weapons"]:
        if w not in wp: issues.append(f"chapter {r['id']}: unknown weapon {w}")
    for v in r["vehicles"]:
        if v not in vh: issues.append(f"chapter {r['id']}: unknown vehicle {v}")
    for a in r["audio"]:
        if a not in au: issues.append(f"chapter {r['id']}: unknown audio {a}")
    if r["next"] and r["next"] not in cid:
        issues.append(f"chapter {r['id']}: unknown next {r['next']}")
for a in ac.values():
    if a["voice_set"] not in au: issues.append(f"actor {a['id']}: voice {a['voice_set']} not in audio")
for w in wp.values():
    if w["sound"] not in au: issues.append(f"weapon {w['id']}: sound {w['sound']} not in audio")
for v in vh.values():
    if v["sound"] not in au: issues.append(f"vehicle {v['id']}: sound {v['sound']} not in audio")
print("\n".join(issues) if issues else "preflight clean")
sys.exit(1 if issues else 0)

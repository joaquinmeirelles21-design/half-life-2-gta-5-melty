# HL2 in Los Santos (design package)

GTA V Enhanced (host, Story Mode) with the Half-Life 2 campaign played through it.
Half-Life 2, Episode One and Episode Two are required companion games; their voices,
music and sound effects are read from the player's own installed copies. Nothing from
any game is included in this package.

Status: DESIGN ONLY. This is not a playable mod yet. It has not been built or tested,
and it has not been published to Melty.

Contents
- sheets/chapters.json: five campaign chapters mapped to GTA locations
- sheets/actors.json: HL2 enemies and allies as GTA peds
- sheets/weapons_vehicles.json: gravity gun, crowbar, SMG, buggy, airboat
- sheets/audio.json: where each sound is read from in the player's own game folders
- preflight.py: run `python3 preflight.py sheets` to check all references resolve

Next steps: build the ASI plugin (loaded by Ultimate ASI Loader), verify the audio
paths against a real install, test through Melty, then publish.
